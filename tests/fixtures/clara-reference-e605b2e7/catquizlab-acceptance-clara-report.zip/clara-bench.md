# CLARA-like benchmark (#110): HIGHESTSUB, about 2 500 items

## after (release engine set)

Engines: {"engine_set": "release", "local_wunderbyte_table": "main d45e1ea0b58549859f1b78b416d34c83d6d280c8 2026111600", "local_catquiz": "ALiSe-v-1.2.0-legacy 2b39e3c030421db6307c5c049cda0a8d0da2eacf 2026111707", "mod_adaptivequiz": "ALiSe-v-1.2.0-legacy 4869fc5fb84805289491ae0f37b24f76766fe3c0 2026111704", "adaptivequizcatmodel_catquiz": "ALiSe-v-1.2.0-legacy fee42fd69592d629ee68c181f86ba69655d3c398 2026111707"}  
Host: {"plugin": "e605b2e78797efae7aed2e190efea5b10b0a3ac5", "run": "45038234242", "runner": "GitHub Actions 1000037858", "image": "20261116.133.1", "cpus": 4}

| step | pool | result | UTC | sittings | answers/min | error rate | 5xx | selector p50/p95 ms | request p50/p95 ms | client wait p50 ms | uncertain (server/client/?) | throttled |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| highestsub-w1 | 2502 | PASS | 2026-11-22T15:31:07Z–2026-11-22T15:32:15Z | 2/2 | 44.1 | 0.0 | 0 | 199.559/205.765 | 28/360 | 6536 | 0/0/0 | 0 |
| highestsub-w5 | 2502 | PASS | 2026-11-22T15:32:43Z–2026-11-22T15:34:43Z | 10/10 | 125.0 | 0.0 | 0 | 286.927/371.247 | 46/626 | 8769 | 0/0/0 | 0 |
| highestsub-w12 | 2502 | PASS | 2026-11-22T15:35:12Z–2026-11-22T15:39:05Z | 24/24 | 154.5 | 0.0 | 0 | 457.625/1076.599 | 102/1526 | 13121 | 0/0/0 | 0 |
| highestsub-w25 | 2502 | PASS | 2026-11-22T15:39:36Z–2026-11-22T15:47:07Z | 50/50 | 166.3 | 0.0 | 0 | 997.304/2868.417 | 206/3863 | 15837 | 0/0/0 | 0 |
| highestsub-w5-querylog | 2502 | PASS | 2026-11-22T15:47:43Z–2026-11-22T15:50:04Z | 10/10 | 106.4 | 0.0 | 0 | 289.243/398.844 | 62/713 | 9539 | 0/0/0 | 0 |
| highestsub-w5-faults | 2502 | PASS | 2026-11-22T15:50:34Z–2026-11-22T15:56:23Z | 10/10 | 43.0 | 0.0 | 0 | 197.753/230.804 | 29/382 | 69219 | 0/30/0 | 108 |

## before (previous engine set)

Engines: {"engine_set": "previous", "local_wunderbyte_table": "main 81ce6cce17bb34b67102fee77e3cfac85a9e6f0b 2026081801", "local_catquiz": "ALiSe-v-1.2.0-legacy ee1f096f72efe9bb619cf82729c47a2abd155fcc 2026100922", "mod_adaptivequiz": "ALiSe-v-1.2.0-legacy d128621d3dfc82712b4a91fd4be21debcf2e0f9e 2026100909", "adaptivequizcatmodel_catquiz": "ALiSe-v-1.2.0-legacy a7ba07555a30d5cd1f812859ed949dd127721dbd 2026101801"}  
Host: {"plugin": "e605b2e78797efae7aed2e190efea5b10b0a3ac5", "run": "45038234242", "runner": "GitHub Actions 1000037880", "image": "20261116.376.1", "cpus": 4}

| step | pool | result | UTC | sittings | answers/min | error rate | 5xx | selector p50/p95 ms | request p50/p95 ms | client wait p50 ms | uncertain (server/client/?) | throttled |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| highestsub-w1 | 2502 | FAIL | 2026-11-22T15:51:33Z–2026-11-22T16:08:20Z | 0/1 | 0.2 | 1.0 | 0 | 124272.517/131892.412 | 31/29546 | None | 2/0/0 | 0 |
| highestsub-w25 | 2502 | FAIL | 2026-11-22T16:09:14Z–2026-11-22T16:39:18Z | 0/25 | None | 1.0 | 0 | 257130.255/290949.794 | 159/784 | None | 0/25/43 | 709 |

## The eight points

- **db-errors** Datenbankfehler: **PASS**
  - 6 step(s): no exception of the database layer, 0 deadlocks, counters read
- **web-limits** PHP-/Webserver-Grenzen dokumentieren: **PASS**
  - {"php_web": {"sapi": "fpm-fcgi", "version": "8.3.6", "memory_limit": "512M", "max_execution_time": "300", "max_input_time": "60", "post_max_size": "8M", "upload_max_filesize": "2M", "default_socket_timeout": "60", "max_input_vars": "8000", "opcache.enable": "1", "opcache.memory_consumption": "128"}, "php_fpm_pool": {"pm": "static", "pm.max_children": "64", "request_terminate_timeout": "300", "listen.backlog": "4096", "php_admin_value[memory_limit]": "512M", "php_admin_value[max_execution_time]": "300"}, "apache": {"Timeout": "300", "ProxyTimeout": "not set (default Timeout)", "KeepAliveTimeout": "5", "MaxRequestWorkers": "150", "ServerLimit": "16", "ThreadsPerChild": "25", "ListenBacklog": "not set (default 511)"}}
  - gateway: none: the workers reach Apache directly (127.0.0.1), no reverse proxy or gateway in between
  - web memory_limit of the steps: ['512M']
- **db-limits** Datenbankseitig: Verbindungen, Locks/Deadlocks, fehlgeschlagene Writes: **PASS**
  - max_connections 100, at most 21 connection(s) in a step, 0 deadlock(s), 0 failed write(s); limits {"family": "postgres", "max_connections": "100", "statement_timeout": "0", "lock_timeout": "0", "idle_in_transaction_session_timeout": "0", "deadlock_timeout": "1000", "superuser_reserved_connections": "3"}
- **AK-CLARA-01** CDP-Timeout-Lebenslauf rekonstruierbar, Seite bestimmt: **PASS**
  - events by cause per step: {"highestsub-w1": {"request_not_received": 0, "response_not_delivered": 0, "server_slow": 0, "server_error": 0, "unattributed": 0}, "highestsub-w5": {"request_not_received": 0, "response_not_delivered": 0, "server_slow": 0, "server_error": 0, "unattributed": 0}, "highestsub-w12": {"request_not_received": 0, "response_not_delivered": 0, "server_slow": 0, "server_error": 0, "unattributed": 0}, "highestsub-w25": {"request_not_received": 0, "response_not_delivered": 0, "server_slow": 0, "server_error": 0, "unattributed": 0}, "highestsub-w5-querylog": {"request_not_received": 0, "response_not_delivered": 0, "server_slow": 0, "server_error": 0, "unattributed": 0}, "highestsub-w5-faults": {"request_not_received": 10, "response_not_delivered": 20, "server_slow": 0, "server_error": 0, "unattributed": 0}}
- **AK-CLARA-03** Selektorzeit getrennt von CDP/Navigation, Apache/PHP, Trace-Persistierung, Lastguard: **PASS**
  - highestsub-w1: selector p50/p95 199.559/205.765 ms, DB p50 11.087 ms, lock wait p95 5.105 ms, client p50 6536 ms, throttled samples 0
  - highestsub-w5: selector p50/p95 286.927/371.247 ms, DB p50 19.284 ms, lock wait p95 1.523 ms, client p50 8769 ms, throttled samples 0
  - highestsub-w12: selector p50/p95 457.625/1076.599 ms, DB p50 41.469 ms, lock wait p95 13.21 ms, client p50 13121 ms, throttled samples 0
  - highestsub-w25: selector p50/p95 997.304/2868.417 ms, DB p50 77.433 ms, lock wait p95 34.387 ms, client p50 15837 ms, throttled samples 0
  - trace INSERT p50/p95 0.85/2.44 ms
- **AK-CLARA-04** Drosselung und Safety-Cap unter 1/5/12/25 Workern gemessen: **PASS**
  - highestsub-w1: live at most 1, limit at least 1, cap none, throttled samples 0
  - highestsub-w5: live at most 5, limit at least 1, cap none, throttled samples 0
  - highestsub-w12: live at most 12, limit at least 1, cap none, throttled samples 0
  - highestsub-w25: live at most 25, limit at least 1, cap none, throttled samples 0
  - before: highestsub-w1 throttled samples 0, guard {"trips": 0, "first": null, "drained": 0, "limit": null}
  - before: highestsub-w25 throttled samples 709, guard {"trips": 1, "first": 1795364117, "drained": 13, "limit": 12}
- **AK-CLARA-05** Alle Sittings terminal und auswertbar; Recovery ohne Doppelabgabe: **PASS**
  - highestsub-w1: 2/2 collected, validity {"valid": 2}
  - highestsub-w5: 10/10 collected, validity {"valid": 10}
  - highestsub-w12: 24/24 collected, validity {"valid": 24}
  - highestsub-w25: 50/50 collected, validity {"valid": 49, "invalid": 1}
  - highestsub-w5-faults: 10/10 collected, validity {"valid": 10}
  - pool [2502]
- **AK-CLARA-05-historical** Runs #87/#88 auf CLARA: **WAIVED**
  - not reconstructable here
  - Waiver: The historical CLARA runs #87 and #88 (Experiment #19, 15.11.2026) are not reconstructable in CI: their database, logs and engine state are the operator's. Waived as operator evidence (re-audit 22.11.2026, section 3 A) — not tested, and not reported as tested. What is tested: the same kind of run (HIGHESTSUB, about 2 500 items) before and after, on the same seeds.
- **DoD-CLARA-01** Vorher/Nachher auf demselben Benchmark (HIGHESTSUB, ~2 500 Items, 1/5/12/25): **PASS**
  - before highestsub-w1 2026-11-22T15:51:33Z–2026-11-22T16:08:20Z: selector p50 124272.517 ms, answers/min 0.2, error rate 1.0, uncertain submissions {"client": 0, "server": 2, "unknown": 0}, result FAIL
  - before highestsub-w25 2026-11-22T16:09:14Z–2026-11-22T16:39:18Z: selector p50 257130.255 ms, answers/min None, error rate 1.0, uncertain submissions {"client": 25, "server": 0, "unknown": 43}, result FAIL
  - after highestsub-w1 2026-11-22T15:31:07Z–2026-11-22T15:32:15Z: selector p50 199.559 ms, answers/min 44.1, error rate 0.0, uncertain submissions {"client": 0, "server": 0, "unknown": 0}, result PASS
  - after highestsub-w5 2026-11-22T15:32:43Z–2026-11-22T15:34:43Z: selector p50 286.927 ms, answers/min 125.0, error rate 0.0, uncertain submissions {"client": 0, "server": 0, "unknown": 0}, result PASS
  - after highestsub-w12 2026-11-22T15:35:12Z–2026-11-22T15:39:05Z: selector p50 457.625 ms, answers/min 154.5, error rate 0.0, uncertain submissions {"client": 0, "server": 0, "unknown": 0}, result PASS
  - after highestsub-w25 2026-11-22T15:39:36Z–2026-11-22T15:47:07Z: selector p50 997.304 ms, answers/min 166.3, error rate 0.0, uncertain submissions {"client": 0, "server": 0, "unknown": 0}, result PASS

## Root cause

- before, highestsub-w1 (2502 items, 1 worker(s)): selector p50 124272.517 ms, p95 131892.412 ms (n 5); uncertain submissions: server side 2, client side 0; FAIL
- before, highestsub-w25 (2502 items, 25 worker(s)): selector p50 257130.255 ms, p95 290949.794 ms (n 25); uncertain submissions: server side 0, client side 25; FAIL
- after, highestsub-w1 (2502 items, 1 worker(s)): selector p50 199.559 ms, p95 205.765 ms (n 52); uncertain submissions: server side 0, client side 0; PASS
- after, highestsub-w5 (2502 items, 5 worker(s)): selector p50 286.927 ms, p95 371.247 ms (n 260); uncertain submissions: server side 0, client side 0; PASS
- after, highestsub-w12 (2502 items, 12 worker(s)): selector p50 457.625 ms, p95 1076.599 ms (n 624); uncertain submissions: server side 0, client side 0; PASS
- after, highestsub-w25 (2502 items, 25 worker(s)): selector p50 997.304 ms, p95 2868.417 ms (n 1300); uncertain submissions: server side 0, client side 0; PASS
Cause, as measured: the selector of the previous engine set took up to 257130 ms per question at this pool size, the release set at most 997 ms; 2 uncertain submission(s) of the before leg were still running on the server when the browser gave up (server side) — the CDP timeouts followed from the selector's time, not from the browser.
